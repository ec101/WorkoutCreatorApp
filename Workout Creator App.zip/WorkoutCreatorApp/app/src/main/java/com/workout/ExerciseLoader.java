package com.workout;

import android.content.res.AssetManager;
import android.content.res.Resources;

import java.util.List;

public interface ExerciseLoader {

    List<Exercise> loadExercies();
}
