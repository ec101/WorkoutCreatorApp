package com.workout;

import java.util.List;

public interface Workout {

	public List<Exercise> getExercises();

}
