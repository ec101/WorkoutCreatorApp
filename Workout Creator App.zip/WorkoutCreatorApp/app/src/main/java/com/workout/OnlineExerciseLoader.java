package com.workout;


import java.util.List;

public class OnlineExerciseLoader implements ExerciseLoader {

    @Override
    public List<Exercise> loadExercies() {
        return null;
    }
}
