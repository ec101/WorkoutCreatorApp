package com.workout;

public interface WorkoutGenerator {

	public Workout generateWorkout();
	
}
