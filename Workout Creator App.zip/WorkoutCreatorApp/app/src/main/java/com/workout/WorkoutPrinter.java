package com.workout;

public interface WorkoutPrinter {

	String printWorkout(Workout workout);
}
